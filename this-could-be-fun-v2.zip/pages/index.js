import {useState} from 'react';

const games=[
["Closer","♥",["What makes you feel most appreciated by me?","What memory of us would you happily relive?","What should we make more time for together?"]],
["Would You Rather","↔",["Lake house or city penthouse?","Spontaneous trip or perfectly planned vacation?","No phones all weekend or no plans all weekend?"]],
["Know Me?","?",["What would I choose for our perfect date?","What food could I eat three nights straight?","What would I buy first if money didn't matter?"]],
["Truth or Dare","!",["TRUTH: What's something you've wanted to tell me but haven't?","DARE: Recreate your first impression of me.","DARE: Give me your best 20-second pickup line."]],
["Wild Card","★",["Plan a $30 date together in 60 seconds.","Show the funniest photo you have of your partner.","Invent a ridiculous couple nickname and use it for three rounds."]],
["After Dark","🔥",["Tell your partner something you find especially attractive about them.","Describe your ideal private date night from beginning to end.","Choose: a long kiss now, or save it as a reward for the next round.","Share a fantasy date scenario you've never suggested before."]]
];

const seed=[
 {n:"Maya",m:"Anyone else choosing Wild Card first?"},
 {n:"Dez",m:"I vote Truth or Dare. Obviously."},
 {n:"Jace",m:"Know Me? is dangerous 😂"}
];

export default function Home(){
 const [screen,setScreen]=useState("home"),[game,setGame]=useState(null),[i,setI]=useState(0);
 const [adult,setAdult]=useState(false),[msgs,setMsgs]=useState(seed),[msg,setMsg]=useState("");
 function play(g){ if(g[0]==="After Dark"&&!adult){setScreen("age");setGame(g);return} setGame(g);setI(0);setScreen("play") }
 function send(e){e.preventDefault();if(!msg.trim())return;setMsgs([...msgs,{n:"You",m:msg.trim()}]);setMsg("")}
 if(screen==="age")return <main className="wrap center"><h1>After Dark</h1><p className="sub">This game is intended for adults 18+.</p><button className="main" onClick={()=>{setAdult(true);setI(0);setScreen("play")}}>I’m 18+ — continue</button><button className="ghost" onClick={()=>setScreen("games")}>Go back</button></main>;
 if(screen==="play")return <main className="wrap"><button className="back" onClick={()=>setScreen("games")}>← Games</button><section className="center"><div className="icon">{game[1]}</div><p className="cap">{game[0]} · {i+1}/{game[2].length}</p><div className="card">{game[2][i]}</div><button className="main" onClick={()=>setI((i+1)%game[2].length)}>Next card</button></section></main>;
 if(screen==="lobby")return <main className="wrap"><button className="back" onClick={()=>setScreen("home")}>← Home</button><h1>Singles Lobby</h1><p className="sub">Meet, chat, then jump into a game room.</p><div className="room"><div className="online"><b>Lobby · 4 online</b><span>AI hosts can keep rooms active</span></div><div className="chat">{msgs.map((x,k)=><div className={x.n==="You"?"mine":""} key={k}><b>{x.n}</b><p>{x.m}</p></div>)}</div><form onSubmit={send}><input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Say something…"/><button>Send</button></form></div><button className="main" onClick={()=>setScreen("games")}>Browse games</button></main>;
 if(screen==="games")return <main className="wrap"><button className="back" onClick={()=>setScreen("home")}>← Home</button><h1>Pick a game</h1><p className="sub">Six ways to make the night more interesting.</p><div className="grid">{games.map((g,k)=><button className={"tile "+(g[0]==="After Dark"?"hot":"")} onClick={()=>play(g)} key={g[0]}><span className="icon">{g[1]}</span><b>{g[0]}</b><small>{g[0]==="After Dark"?"18+":"Tap to play"}</small></button>)}</div></main>;
 return <main className="wrap home"><div className="logo">∞</div><p className="cap">THIS COULD BE FUN</p><h1>Who are you playing with?</h1><p className="sub">A game night for couples — and a place for singles to meet and play.</p><div className="choices"><button onClick={()=>setScreen("games")}><b>Couples</b><span>Six games for two →</span></button><button onClick={()=>setScreen("lobby")}><b>Singles</b><span>Enter the chat lobby →</span></button></div></main>
}